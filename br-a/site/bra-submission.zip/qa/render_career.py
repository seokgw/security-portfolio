import os
import runpy
import sys

os.environ['PATH'] = (
    r'C:\Users\Administrator\Documents\ChatGPT\SKT_ALEPH\T10_checkpoint_20260911\renderer\program;'
    r'C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin;'
    + os.environ.get('PATH', '')
)
sys.argv = [
    'render_docx.py',
    r'C:\Users\Administrator\Documents\ChatGPT\SKT_ALEPH\br-a\documents\career-description.docx',
    '--output_dir',
    r'C:\Users\Administrator\Documents\ChatGPT\SKT_ALEPH\br-a\qa\career-final',
    '--emit_pdf',
    '--verbose',
]
runpy.run_path(
    r'C:\Users\Administrator\.codex\plugins\cache\openai-primary-runtime\documents\26.905.11957\skills\documents\render_docx.py',
    run_name='__main__',
)
