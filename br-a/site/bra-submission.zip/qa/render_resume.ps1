$env:PATH = 'C:\Users\Administrator\Documents\ChatGPT\SKT_ALEPH\T10_checkpoint_20260911\renderer\program;C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin;' + $env:PATH
& 'C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' `
  'C:\Users\Administrator\.codex\plugins\cache\openai-primary-runtime\documents\26.905.11957\skills\documents\render_docx.py' `
  'C:\Users\Administrator\Documents\ChatGPT\SKT_ALEPH\br-a\documents\resume.docx' `
  --output_dir 'C:\Users\Administrator\Documents\ChatGPT\SKT_ALEPH\br-a\qa\resume-updated' `
  --emit_pdf `
  --verbose
exit $LASTEXITCODE
