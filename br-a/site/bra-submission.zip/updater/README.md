# BR A 기록 자동 갱신 장치

리추얼 원본 구조를 직접 파싱해 숫자와 능력별 문단 후보를 계산합니다. 승인된 문장만 공개용 `index.html`에 넣습니다. API나 네트워크 호출은 없습니다.

## 새 폴더에서 실행하는 세 단계

1. Python 3.10 이상을 준비하고 ZIP을 풉니다. `updater` 폴더에서 `python -m pip install -r requirements.txt`를 실행합니다. 검증 환경은 Python 3.12 및 python-docx 1.2.0입니다.
2. `input/ritual-history.json`에 본인의 익명화된 실제 기록을 배치합니다. 함께 제공된 출석·제출·승인 파일과 초안, 공개 논문 사본을 유지합니다.
3. `python update.py`를 실행합니다. `output/site/index.html`은 승인된 내용의 공개용 페이지, `output/site/review.html`은 로컬 검토용 페이지입니다. 문서는 `output/documents/`에 생깁니다.

검토용 페이지는 외부에 게시하지 않습니다. 사이트와 세 문서, 숫자가 하나의 입력에서 함께 갱신됩니다.

## 입력

| 파일 | 내용 |
|---|---|
| ritual-history.json | student와 days. 각 날짜에 date, open, close 필수. open/close는 문자열 배열 또는 null |
| attendance.json | status, source, records. confirmed일 때 각 항목은 date와 status(present/absent/excused) |
| assignments.json | status, source, records. confirmed일 때 각 항목은 id와 submitted(true/false) |
| approved-statements.json | 사용자 선택 한 줄 소개, 기존 사용자 작성 첫·마지막 문장, 승인 본문, 능력 설명, 연락 수단 하나, 실제 공개 주소 |
| content-draft.json | 승인 전 자기소개 문단과 능력 설명, 한 줄 소개 3개, 근거가 있는 과제 경험 |
| paper-public.md | 실제 과제 10 논문의 공개용 익명화 사본 |

출석과 제출은 자료를 확보한 뒤에만 confirmed로 바꾸고 근거 출처를 기록합니다. 현재 빈 배열은 0%를 뜻하지 않습니다. 날짜 중복·잘못된 날짜·미지의 상태·필수 필드 누락을 오류로 처리합니다.

각 날짜는 아침 또는 마무리 중 하나 이상의 실제 기록이 있어야 합니다. 마무리 기록이 있으면 `강점 행동: 실천했다`, `강점 행동: 일부 실천했다`, `강점 행동: 못 했다` 중 하나가 정확히 한 번 있어야 합니다. 비어 있는 날짜나 상태가 없는 마무리를 실천으로 표시하지 않습니다.

## 승인 후 반영

사용자가 본문을 검토하고 승인했을 때만 `content-draft.json`의 `paragraphs`를 `approved-statements.json`의 `story`에 복사합니다. 같은 방법으로 능력 설명 `capabilities`도 승인된 내용만 복사합니다. 첫 문장과 마지막 문장은 과제 9에서 사용자가 직접 작성한 것을 그대로 사용합니다. 이번 BR-A에서 이를 다시 선택한 것으로 기록하지 않습니다.

`{{record_days}}` 같은 집계 자리는 승인된 문장 안에서도 최신 입력의 실제 숫자로 치환됩니다. 미등록 자리표시자는 오류입니다. 새 기록으로 기존 인용의 근거가 사라지면 입력 검증에 실패합니다. 후보 목록을 자동으로 승인 파일에 복사하는 기능은 없습니다.

연락 수단은 사용자가 정한 하나만 `{"label":"연락 방법","value":"사용자가 공개하기로 정한 값"}` 형식으로 저장합니다. 실제 HTTPS 주소가 확인되면 `public_url`에 입력합니다. `approval_note`에 실제 승인 내용을 남깁니다.

공개 전에는 `python update.py --publish --output public-build`를 실행합니다. 본문·능력 3개·한 줄 소개의 승인이 없으면 중단합니다. 연락 수단은 미제공 시 TODO로 표시하며 URL은 실제 배포 확인 후 기록합니다. 공개 폴더는 반드시 새 폴더로 만드세요. `public-build/site/`만 게시하며 입력·후보·검토 페이지는 게시하지 않습니다. 사이트 호스팅 자체는 이 스크립트의 기능이 아닙니다.

## 출력

- `metrics.json`: 날짜별 집계, 반복 행동의 원문별 날짜 수, 미확정 자료 상태.
- `candidates.json`: 능력별 날짜·출처·원문·문단 후보. 키워드 분류는 검토 편의 기능이며 능력 점수가 아닙니다. 타인에게 한 칭찬과 미래의 다짐은 후보에서 제외합니다.
- `story-draft.txt`: 실제 집계 숫자를 넣은 약 1500자 자기소개 검토문.
- `site/`: 정적 HTML, CSS, 숫자 JSON, 논문 공개용 사본, DOCX.
- `documents/`: 이력서·자기소개서·경력기술서. 새 본문 미승인 시 자기소개서에 검토용 상태 표시.
- `manifest.json`: 파일별 SHA-256 및 정렬된 해시 목록의 종합 SHA-256.
- `last-run.json`: 성공 여부, 입력 해시, 경고, 본문 글자 수, 종합 해시. 실행 시각은 결정성을 위해 포함하지 않습니다.

현재 시간이나 난수, 외부 AI API에 의존하지 않습니다. DOCX 내부 ZIP 시간과 문서 메타데이터도 고정합니다. 다른 Python/압축 라이브러리 버전 간 바이트 동일성까지 보장하지는 않습니다. 같은 실행 환경과 같은 입력으로 검증합니다.

## 재현성 검증

`updater`에서 `python verify.py`를 실행합니다. 제출에 필요한 소스·입력·템플릿만 새 임시 폴더에 복사하고 같은 명령을 두 번 실행합니다. 모든 파일의 SHA-256을 비교합니다. 잘못된 JSON, 필수 필드 누락, 중복 날짜, 잘못된 승인 근거와 미승인 공개 시도도 확인합니다. 오류 때 기존 출력이 바뀌지 않는지 검사합니다. 결과는 `reproducibility.json`에 저장됩니다.

수동 확인 명령:

```text
python update.py --output run1
python update.py --output run2
python verify.py
```

사이트를 확인하려면 출력의 `site` 폴더에서 `python -m http.server 8765 --bind 127.0.0.1`을 실행하고 브라우저로 로컬 주소를 엽니다. 파일을 직접 열어도 기본 열람과 이동이 작동합니다.

제출 폴더와 ZIP까지 갱신하려면 결과를 검토한 다음 `python privacy_check.py`, `python check_bra.py`, `python package.py`를 실행합니다. `package.py`는 최신 `output`의 문서와 사이트를 제출 루트로 복사하고 루트의 상위 폴더에 ZIP을 만듭니다. 웹 공개 접근 검사는 실제 게시한 뒤 별도로 다시 수행해야 하며, 로컬 검사만으로 시크릿 창 기준을 PASS로 바꾸지 않습니다.

## 오류 확인

`ERROR` 뒤의 입력 이름과 원인을 확인합니다. UTF-8 JSON, 날짜 형식, 필수 필드, 중복 날짜 및 승인 근거 원문을 확인하세요. `ModuleNotFoundError`는 1단계 패키지 설치 여부를 확인합니다. 입력을 모두 검증하고 문서를 메모리에 생성한 뒤에만 출력에 쓰므로 잘못된 입력은 기존 결과물을 훼손하지 않습니다. 디스크 장애 중 여러 파일에 대한 전체 트랜잭션까지 보장하지는 않습니다.

## 개인정보

공개 이름은 석근욱만 사용합니다. 리추얼 제공본의 타인 이름 가림을 유지하고 논문 연구자 이름도 익명화했습니다. 새 입력은 추가 전에 직접 실명·연락처를 검토하세요. 문자열 검사만으로 알려지지 않은 모든 사람 이름을 자동 판별할 수는 없습니다. 이 프로젝트에는 API 자격 증명이 필요 없습니다.
