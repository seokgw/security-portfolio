"""Check implemented requirements, leaving unavailable evidence unconfirmed."""
from pathlib import Path
from html.parser import HTMLParser
import json
import re
import zipfile
from docx import Document

ROOT=Path(__file__).resolve().parent.parent


class Links(HTMLParser):
    def __init__(self): super().__init__(); self.links=[]; self.ids=set()
    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.add(attrs['id'])
        for key in ('href','src'):
            if key in attrs:self.links.append(attrs[key])


def main():
    a=json.loads((ROOT/'updater/input/approved-statements.json').read_text(encoding='utf-8'))
    d=json.loads((ROOT/'updater/input/content-draft.json').read_text(encoding='utf-8'))
    m=json.loads((ROOT/'updater/output/metrics.json').read_text(encoding='utf-8'))
    r=json.loads((ROOT/'updater/reproducibility.json').read_text(encoding='utf-8'))
    privacy=json.loads((ROOT/'evidence/privacy.json').read_text(encoding='utf-8'))
    web=json.loads((ROOT/'evidence/public-access.json').read_text(encoding='utf-8'))
    site=(ROOT/'site/index.html').read_text(encoding='utf-8')
    submission=(ROOT/'submission.md').read_text(encoding='utf-8')
    intro=Document(ROOT/'documents/self-introduction.docx')
    paragraphs=[p.text for p in intro.paragraphs]
    doc_text='\n'.join(paragraphs)
    career='\n'.join(p.text for p in Document(ROOT/'documents/career-description.docx').paragraphs)
    checks={}
    def check(code,condition,evidence):checks[code]={'status':'PASS' if condition else 'FAIL','evidence':evidence}
    check('BRA-C01',all(x in doc_text for x in ['2021년','고치려고 노력','2023년','취업 준비']) and a['story'] is not None,'고난·행동 변화·현재의 서사. 군 복무의 정확한 전환일은 미상으로 유지. 수업 고비의 08-18/19 날짜 확인.')
    check('BRA-C02',{x['ability'] for x in a['capabilities']}=={'자기조절력','대인관계력','자기동기력'},'심호흡 08-12, 동료 도움 08-25, 팀 과제 완수 09-02. 입력 원문 인용 검증 통과.')
    check('BRA-C03',a['name'] in site and a['tagline'] in site and a['tagline'].endswith('한 사람'),'사용자가 고른 한 줄 소개와 이름 표시.')
    check('BRA-C04',all(x in site for x in ['2026-08-12','2026-08-25','2026-09-02']),'날짜가 확인된 실제 리추얼 장면 3개. 작성일과 사건일 구분.')
    checks['BRA-C05']={'status':'UNCONFIRMED','evidence':f'제공된 {m["record_days"]}일 기록과 {m["close_count"]}건 마무리는 실제 파싱·출처 표기 완료. 13주 전체·출석·공식 제출 자료 미제공으로 전체 범위 충족은 확인 불가.'}
    check('BRA-C06',(ROOT/'site/paper.html').exists() and '과제 13 완료 후 추가 예정' in site,'실제 과제 10 공개용 익명화 사본과 과제 13 자리.')
    names=['resume.docx','self-introduction.docx','career-description.docx']
    check('BRA-C07',all((ROOT/'documents'/n).is_file() for n in names),'DOCX 3종 존재. 1쪽·1쪽·2쪽 전체 렌더 검수.')
    check('BRA-C08',all(career.count(x)>=len(d['projects']) for x in ['해당 능력:','상황:','행동:','결과:']),'각 경험에 능력·상황·행동·결과. 미확인 결과물은 자기보고 한계 명시.')
    check('BRA-C09',r['result']=='PASS' and r['same_files'],'새 임시 폴더에서 README 실행 명령 두 번. 모든 출력 파일 SHA-256 일치. 오류 입력 보존 검사 통과.')
    check('BRA-C10',privacy['status']=='PASS','현재 제출 범위 텍스트·DOCX 내부 및 인명 문맥 검사. 타인 이름 가림, 승인 이메일 하나, 비밀값 미발견. 새 입력까지 보장하지 않음.')
    check('BRA-C11',all(x in submission for x in ['site/','documents/','updater/','ZIP','이야기','숫자','대표작']),'submission.md에 실제 주소와 위치, 확인 3단계.')
    check('BRA-C12',all(x in submission for x in ['①','②','③','과제 9','이번']),'AI 작업·사용자 판단·과거 AI 제안 정정 분리. 과거 결정을 이번 결정으로 꾸미지 않음.')
    checks['BRA-C13']={'status':'PASS' if web.get('incognito_window')=='PASS' else 'UNCONFIRMED','evidence':'HTTPS 9개 리소스 인증·쿠키 없는 요청 200 및 로컬 바이트 일치. 새 일반 브라우저 탭 열람 확인. 실제 시크릿 창 UI 검사는 미확인.'}
    field=submission.split('## 결과물',1)[1].split('## 확인 방법',1)[0]
    check('BRA-C20',len(re.findall(r'https://\S+',field))==1,'제출문 결과물 필드의 HTTPS URL 정확히 1개.')
    encrypted=[]
    for p in [ROOT/'documents'/n for n in names]+[ROOT/'site/bra-submission.zip']:
        with zipfile.ZipFile(p) as z:
            if z.testzip() is not None or any(x.flag_bits & 1 for x in z.infolist()):encrypted.append(p.name)
            if p.suffix=='.docx' and b'documentProtection' in z.read('word/settings.xml'):encrypted.append(p.name)
    check('BRA-C21',not encrypted,'ZIP CRC 검사와 암호화 플래그 확인. DOCX 열기 및 보호 설정 검사.')
    broken=[]
    for name in ['index.html','paper.html']:
        parser=Links();parser.feed((ROOT/'site'/name).read_text(encoding='utf-8'))
        for link in parser.links:
            if link.startswith('#'):
                if link[1:] not in parser.ids:broken.append(link)
            elif not re.match(r'[a-z]+:',link) and not (ROOT/'site'/link.split('#')[0]).exists():broken.append(link)
    check('LOCAL-LINKS',not broken,'사이트 내부 링크와 파일 경로 검증.')
    result={'checks':checks,'overall':'FAIL' if any(x['status']=='FAIL' for x in checks.values()) else 'PARTIAL — 13주 전체 자료 및 시크릿 창 확인 필요','same_input_sha256':r['run1_sha256'],'broken_links':broken}
    (ROOT/'evidence/bra-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# BR A 최종 검증','', '| 기준 | 결과 | 근거 |','|---|---|---|']+[f'| {code} | {x["status"]} | {x["evidence"]} |' for code,x in checks.items()]
    lines+=['','실행 1 SHA-256: `'+r['run1_sha256']+'`','', '실행 2 SHA-256: `'+r['run2_sha256']+'`','','동일 여부: MATCH. 집계·후보·사이트·문서 전체 출력 비교.']
    (ROOT/'evidence/BRA-validation.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({k:v['status'] for k,v in checks.items()}))
    return 1 if result['overall']=='FAIL' else 0


if __name__=='__main__':raise SystemExit(main())
