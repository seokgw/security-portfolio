"""Assemble the requested folder layout and a deterministic submission ZIP."""
from pathlib import Path
import shutil
import zipfile
import hashlib

ROOT = Path(__file__).resolve().parent.parent


def main():
    source = ROOT/'updater/output'
    shutil.copytree(source/'documents', ROOT/'documents', dirs_exist_ok=True)
    for path in sorted((source/'site').rglob('*')):
        if path.is_file() and path.name not in ('review.html', 'bra-submission.zip'):
            destination = ROOT/'site'/path.relative_to(source/'site')
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(path,destination)
    archive=ROOT.parent/'BR-A_석근욱_제출.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file() or path.suffix == '.zip' or '__pycache__' in path.parts or path.name == 'review.html':
                continue
            info=zipfile.ZipInfo(path.relative_to(ROOT).as_posix(),(2000,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16
            z.writestr(info,path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and all(not i.flag_bits & 1 for i in z.infolist())
    shutil.copyfile(archive,ROOT/'site/bra-submission.zip')
    print('ZIP SHA-256 '+hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
