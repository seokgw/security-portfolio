"""Scan submission text and DOCX XML without printing possible secret values."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parent.parent
PATTERN=re.compile(r'password|passwd|secret|token|api_key|authorization|bearer|private_key',re.I)
SECRET=re.compile(r'(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)')
EMAIL=re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')


def main():
    approved=json.loads((ROOT/'updater/input/approved-statements.json').read_text(encoding='utf-8'))
    allowed=approved['contact']['value'] if approved['contact'] else None
    hits=[]; suspicious=[]; checked=0
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix=='.zip' or path.name=='privacy.json':
            continue
        content=[]
        if path.suffix=='.docx':
            with zipfile.ZipFile(path) as z:
                content=[z.read(n).decode('utf-8') for n in z.namelist() if n.endswith('.xml')]
                if any(i.flag_bits & 1 for i in z.infolist()): suspicious.append({'file':path.relative_to(ROOT).as_posix(),'reason':'암호화 항목'})
        else:
            try:content=[path.read_text(encoding='utf-8-sig')]
            except UnicodeError:continue
        checked+=1
        for text in content:
            keywords=sorted(set(x.lower() for x in PATTERN.findall(text)))
            if keywords:hits.append({'file':path.relative_to(ROOT).as_posix(),'keywords':keywords,'review':'검사 코드·라이브러리 XML·검사 기록의 용어. 실제 비밀값과 구별'})
            if SECRET.search(text):suspicious.append({'file':path.relative_to(ROOT).as_posix(),'reason':'자격 증명 형태'})
            if any(x!=allowed for x in EMAIL.findall(text)) and path.name!='privacy_check.py':suspicious.append({'file':path.relative_to(ROOT).as_posix(),'reason':'승인되지 않은 이메일'})
    result={'status':'PASS' if not suspicious else 'FAIL','files_checked':checked,'keyword_hits':hits,'suspicious_values':suspicious,'manual_review':'제공된 리추얼의 동료 이름 가림과 남은 한국어 인명 문맥을 검토. 본인 외 개인 이름 없음. 논문 연구자 이름은 공개 사본에서 가림. 문서 본문·메타데이터 검토. 일반 역할명은 유지. 새 입력의 미지 실명을 자동 검출한다는 보장은 없음.','contact':'사용자가 제공한 이메일 하나만 허용','source_ritual_sha256':hashlib.sha256((ROOT/'updater/input/ritual-history.json').read_bytes()).hexdigest()}
    (ROOT/'evidence').mkdir(exist_ok=True)
    (ROOT/'evidence/privacy.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(result['status']+' '+str(checked)+' files')
    return 0 if not suspicious else 1


if __name__=='__main__':
    raise SystemExit(main())
