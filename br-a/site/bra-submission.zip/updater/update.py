"""BR-A deterministic generator. No network calls. Python 3.10+, python-docx 1.2.0."""
import argparse
from collections import Counter
from datetime import date, datetime
import hashlib
import html
import io
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile
import zipfile

BASE = Path(__file__).resolve().parent
FIXED_TIME = (2000, 1, 1, 0, 0, 0)
for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, 'reconfigure'):
        stream.reconfigure(encoding='utf-8')


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode('utf-8')


def read_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError) as exc:
        raise ValueError(f'{path.name}: JSON을 읽을 수 없습니다 ({type(exc).__name__})') from exc


def ensure(condition, message):
    if not condition:
        raise ValueError(message)


def valid_date(value):
    ensure(isinstance(value, str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}', value), '날짜 형식은 YYYY-MM-DD입니다')
    date.fromisoformat(value)


def validate_optional(data, kind):
    ensure(isinstance(data, dict) and data.get('status') in ('unconfirmed', 'confirmed'), f'{kind}: 상태 필드 오류')
    ensure(isinstance(data.get('source'), str) and data['source'].strip(), f'{kind}: 출처 필수')
    ensure(isinstance(data.get('records'), list), f'{kind}: records 배열 필수')
    ensure(data['status'] == 'confirmed' or not data['records'], f'{kind}: 미확정 자료로 숫자를 만들 수 없습니다')
    seen = set()
    for item in data['records']:
        key = item.get('date') if kind == 'attendance' else item.get('id')
        ensure(isinstance(key, str) and key and key not in seen, f'{kind}: 식별자 누락 또는 중복')
        seen.add(key)
        if kind == 'attendance':
            valid_date(key)
            ensure(item.get('status') in ('present', 'absent', 'excused'), '출석 상태 오류')
        else:
            ensure(type(item.get('submitted')) is bool, '제출 여부는 true/false여야 합니다')
    return data


def load_inputs(folder):
    names = ['ritual-history.json', 'attendance.json', 'assignments.json', 'approved-statements.json', 'content-draft.json']
    data = {name: read_json(folder / name) for name in names}
    ritual = data['ritual-history.json']
    ensure(isinstance(ritual, dict) and ritual.get('student') == '석근욱', '리추얼 student 확인 필요')
    ensure(isinstance(ritual.get('days'), list) and ritual['days'], '리추얼 days는 비어 있지 않은 배열이어야 합니다')
    seen = set()
    for day in ritual['days']:
        ensure(isinstance(day, dict), '날짜별 기록 형식 오류')
        valid_date(day.get('date'))
        ensure(day['date'] not in seen, '중복 기록 날짜: ' + day['date'])
        seen.add(day['date'])
        for key in ('open', 'close'):
            ensure(key in day, f'{day["date"]}: {key} 필드 누락')
            ensure(day[key] is None or (isinstance(day[key], list) and all(isinstance(x, str) for x in day[key])), f'{key}: 문자열 배열 또는 null 필수')
        statuses = [x.split(':', 1)[1].strip() for x in (day['close'] or []) if x.startswith('강점 행동:')]
        ensure(bool(day['open']) or bool(day['close']), f'{day["date"]}: 비어 있는 날짜는 기록일로 집계할 수 없습니다')
        ensure(not day['close'] or len(statuses) == 1, f'{day["date"]}: 마무리 기록에 강점 행동 상태가 필요합니다')
        ensure(len(statuses) <= 1 and all(x in ('실천했다', '일부 실천했다', '못 했다') for x in statuses), f'{day["date"]}: 강점 행동 값 오류')
    for name in ('attendance', 'assignments'):
        validate_optional(data[name + '.json'], name)
    approved = data['approved-statements.json']
    ensure(approved.get('schema_version') == 1 and approved.get('name') == '석근욱', '승인 파일 버전/이름 오류')
    for key in ('first_sentence', 'last_sentence', 'boundary_sentence_source'):
        ensure(isinstance(approved.get(key), str) and approved[key].strip(), f'승인 파일 {key} 필수')
    ensure(approved.get('tagline') is None or (isinstance(approved['tagline'], str) and approved['tagline'].endswith('한 사람')), '한 줄 소개는 한 사람으로 끝나야 합니다')
    ensure(approved.get('story') is None or (isinstance(approved['story'], list) and approved['story'] and all(isinstance(x, str) for x in approved['story'])), '승인 본문은 문단 배열 또는 null')
    ensure(isinstance(approved.get('capabilities'), list), '승인 능력은 배열이어야 합니다')
    if approved.get('contact') is not None:
        c = approved['contact']
        ensure(isinstance(c, dict) and set(c) == {'label', 'value'} and all(isinstance(x, str) and x.strip() for x in c.values()), '연락 수단은 label/value 하나만 제공')
    if approved.get('public_url') is not None:
        ensure(isinstance(approved['public_url'], str) and approved['public_url'].startswith('https://'), '공개 주소는 실제 HTTPS 주소만 입력')
    draft = data['content-draft.json']
    ensure(isinstance(draft.get('paragraphs'), list) and all(isinstance(x, str) for x in draft['paragraphs']), '본문 초안 형식 오류')
    ensure(isinstance(draft.get('taglines'), list) and len(draft['taglines']) == 3 and all(x.endswith('한 사람') for x in draft['taglines']), '한 줄 소개 후보 3개 필수')
    for cap in draft.get('capabilities', []) + approved['capabilities']:
        ensure(all(isinstance(cap.get(x), str) and cap[x] for x in ('ability', 'date', 'source', 'evidence', 'paragraph')), '능력 근거 필드 누락')
        valid_date(cap['date'])
        ensure(any(d['date'] == cap['date'] and any(cap['evidence'] in line for line in (d['open'] or []) + (d['close'] or [])) for d in ritual['days']), '능력 근거가 원문에 없습니다')
    for p in draft.get('projects', []):
        ensure(all(isinstance(p.get(x), str) and p[x] for x in ('id','title','period','ability','situation','action','result','tools','source')), '경력기술서 과제 필드 누락')
    return data


def metrics(data):
    days = sorted(data['ritual-history.json']['days'], key=lambda d: d['date'])
    counts = Counter(line.split(':', 1)[1].strip() for d in days for line in (d['close'] or []) if line.startswith('강점 행동:'))
    closed = [d for d in days if d['close']]
    failed = [d['date'] for d in days if '강점 행동: 못 했다' in (d['close'] or [])]
    last_setback = data['content-draft.json']['setback_date']
    ensure(last_setback in failed, '본문 고비 날짜의 미실천 기록을 확인할 수 없습니다')
    frequencies = Counter()
    for d in days:
        phrases = {line.split(':', 1)[1].strip() for line in (d['close'] or []) if line.startswith('강점을 위해 노력하고 생각한 것:')}
        frequencies.update(phrases)
    result = dict(record_days=len(days), open_count=sum(bool(d['open']) for d in days), close_count=len(closed),
                  practiced=counts['실천했다'], partial=counts['일부 실천했다'], not_practiced=counts['못 했다'],
                  unclassified_close=len(closed)-sum(counts.values()), period=days[0]['date']+'~'+days[-1]['date'],
                  missing_close_dates=[d['date'] for d in days if not d['close']], last_setback=last_setback,
                  after_setback_close=sum(d['date'] > last_setback for d in closed) if last_setback else 0,
                  source='ritual-history.json / days', counting_rule='날짜별 비어 있지 않은 open/close를 각 1건 집계. 줄 수가 아님. 강점 행동은 자기보고.',
                  repeated_actions=[{'text': k, 'date_count': v} for k, v in sorted(frequencies.items(), key=lambda x: (-x[1], x[0]))])
    for kind in ('attendance', 'assignments'):
        d = data[kind + '.json']
        result[kind] = {'status': d['status'], 'source': d['source'], 'total': len(d['records']) if d['status'] == 'confirmed' else None}
        if d['status'] == 'confirmed':
            result[kind]['count'] = sum(x['status'] == 'present' for x in d['records']) if kind == 'attendance' else sum(x['submitted'] for x in d['records'])
    return result


def candidates(data):
    rules = {'자기조절력': ('심호흡', '물', '검색', '점검', '확인'), '대인관계력': ('도와', '경청', '들어', '배려', '양보'), '자기동기력': ('완수', '완료', '끝까지', '마무리')}
    output = []
    for day in sorted(data['ritual-history.json']['days'], key=lambda d: d['date']):
        for phase in ('open', 'close'):
            for line in day[phase] or []:
                # Intentions and compliments about another person cannot evidence the student's action.
                if not (line.startswith(('강점이 드러난 일화:', '강점을 위해 노력하고 생각한 것:')) or re.match(r'동료 \d+가 (말해 준 내 장점|나눈 감사):', line)):
                    continue
                for ability, words in rules.items():
                    if any(word in line for word in words):
                        output.append({'ability': ability, 'date': day['date'], 'source': 'ritual-history.json / '+phase,
                                       'evidence': line, 'evidence_type': '동료 기록' if line.startswith('동료') else '자기 기록',
                                       'paragraph': f'{day["date"]} 기록에는 “{line.split(":", 1)[1].strip()}”라는 내용이 남아 있습니다.',
                                       'status': '검토 후보 — 키워드 분류이며 능력 점수가 아님'})
    return output


def expand(text, stats):
    def replace(match):
        ensure(match[1] in stats and isinstance(stats[match[1]], (int, str)), '알 수 없는 집계 자리표시자')
        return str(stats[match[1]])
    return re.sub(r'\{\{([a-z_]+)\}\}', replace, text)


def story(data, stats, preview=False):
    a = data['approved-statements.json']
    body = a['story'] or (data['content-draft.json']['paragraphs'] if preview else [])
    if not body:
        return []
    return [a['first_sentence']] + [expand(p, stats) for p in body] + [a['last_sentence']]


def make_docx(title, sections):
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor
    from docx.oxml.ns import qn
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.top_margin, sec.bottom_margin = Cm(1.8), Cm(1.8)
    sec.left_margin = sec.right_margin = Cm(2)
    for name in ('Normal', 'Title', 'Heading 1', 'Heading 2'):
        s = doc.styles[name]
        s.font.name = 'Malgun Gothic'
        fonts = s.element.get_or_add_rPr().rFonts
        for attr in list(fonts.attrib):
            if 'Theme' in attr or 'theme' in attr:
                del fonts.attrib[attr]
        for attr in ('ascii','hAnsi','eastAsia','cs'):
            fonts.set(qn('w:'+attr), 'Malgun Gothic')
        s.font.color.rgb = RGBColor(0, 0, 0)
        s.font.size = Pt(10.5 if name == 'Normal' else 13 if name.startswith('Heading') else 24)
        s.paragraph_format.space_after = Pt(7)
        s.paragraph_format.line_spacing = 1.18
    for element in doc.styles.element.iter():
        for child in list(element):
            if child.tag == qn('w:pBdr'):
                element.remove(child)
    doc.add_paragraph(title, 'Title')
    for heading, paragraphs in sections:
        if title == '석근욱 이력서' and heading == '프로젝트와 활동':
            doc.add_page_break()
        if heading:
            doc.add_paragraph(heading, 'Heading 1')
        for text in paragraphs:
            p = doc.add_paragraph(text)
            p.paragraph_format.widow_control = True
    props = doc.core_properties
    props.author, props.last_modified_by = '석근욱', '석근욱'
    props.title = title
    props.created = props.modified = datetime(2000, 1, 1)
    props.revision = 1
    props.comments = ''
    stream = io.BytesIO()
    doc.save(stream)
    # Normalize ZIP entry dates and order as OOXML is itself a ZIP container.
    result = io.BytesIO()
    with zipfile.ZipFile(stream) as source, zipfile.ZipFile(result, 'w', compression=zipfile.ZIP_DEFLATED) as target:
        for name in sorted(source.namelist()):
            info = zipfile.ZipInfo(name, FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            target.writestr(info, source.read(name))
    return result.getvalue()


def build_docs(data, stats):
    a, d = data['approved-statements.json'], data['content-draft.json']
    contact = a['contact']['label'] + ': ' + a['contact']['value'] if a['contact'] else '연락 수단 TODO: 사용자 확인 필요'
    resume = [('기본 정보', ['석근욱', contact, a['tagline'] or '한 줄 소개 TODO: 사용자 확인 필요']),
              ('경력', [
                  '육군본부 | 정보통신 하사 | 2022.06 - 2024.06 (2년 1개월)\nC4I 서버와 국방망 체계를 운영하고 관리했습니다.',
                  '㈜신라시스템 | 개발1팀 사원·팀원 | 2025.03 - 2026.05 (1년 3개월)\n웹사이트 유지보수와 기능 개선 업무를 담당했습니다.'
              ]),
              ('학력', ['구미대학교 | 전자공학 | 2·3년제 졸업']),
              ('교육', ['한국IT교육원 | 백엔드 Java 프레임워크 개발 실무 | 2024.07.31 - 2025.02.19\nJava, Spring Framework, MyBatis 등을 활용한 백엔드 개발 과정을 이수했습니다.']),
              ('기술', [
                  '백엔드: Java, Spring Framework, Spring MVC, MyBatis, iBatis, JSP',
                  '웹·데이터베이스: JavaScript, jQuery, MySQL, MariaDB',
                  '개발 도구·환경: Apache Maven, Apache Tomcat, JUnit, SVN',
                  '기타: GUI, SI 개발, 백엔드·서버 개발, 알고리즘'
              ]),
              ('자격', [
                  '네트워크관리사 2급 | 한국정보통신자격협회 | 2023.10',
                  '전자기능사 | 한국산업인력공단 | 2018.07',
                  '컴퓨터활용능력 2급 | 대한상공회의소 | 2014.02'
              ]),
              ('프로젝트와 활동', [
                  '과제 9 나를 말하는 에이전트 | 2026.09\n리추얼 기록과 실제 경험을 바탕으로 자기소개 콘텐츠를 구성하고, 공개 전 개인정보와 문장 승인 범위를 점검했습니다.\n활용: JSON, Markdown, HTML, CSS, AI 보조',
                  '과제 10 공개자료 연구 논문 | 2026.09\n공개자료의 원문·표·한계를 검토하고, 현재 자료만으로 가설을 판단하기 어렵다는 결론을 반영해 연구 문서를 작성했습니다.\n활용: Python, pdfplumber, matplotlib, DOCX, AI 보조 구현',
                  '과제 11 내일의 첫 줄 | 2026.09\n여러 시기의 경험을 돌아보는 서사 창작 문서를 DOCX로 제작했습니다. 작품 속 가상 학력과 근무 기간은 실제 이력에 포함하지 않았습니다.',
                  f'기록 기반 활동 | {stats["period"]}\n리추얼을 {stats["record_days"]}일 기록하고 마무리 기록 {stats["close_count"]}건을 남기며 행동을 점검했습니다.',
                  '과제 13 | 결과물 완성 후 추가 예정'
              ])]
    introduction = [('석근욱', (["새 본문 검토용 · 첫 문장과 마지막 문장은 과제 9의 사용자 작성문 유지"] if not a['story'] else []) + story(data, stats, True))]
    career = [
        ('경험 범위', ['정규 근무 중 참여한 기술사업과 과제·학습 기록을 구분해 정리했습니다. 학력·교육·자격 정보는 이력서에서 확인할 수 있습니다.']),
        ('신라시스템 기술경력', [
            '공통 담당 업무: 개발이 완료된 시스템의 유지보수, 기능 개선 및 추가 개발을 담당했습니다.',
            '국립공원 안전가이드 예약시스템 유지보수\n참여 기간: 2026.03.20 - 2026.04.28\n분야: SW개발 > 응용SW개발',
            '2025년 청주시시설관리공단 통합회원관리시스템 유지관리 용역\n참여 기간: 2026.03.09 - 2026.04.28\n분야: SW개발 > 응용SW개발',
            '2026년 한라산 탐방객관리시스템 유지관리\n참여 기간: 2026.01.01 - 2026.04.28\n분야: SW개발 > 응용SW개발',
            '2024-2026년 국립공원 자원봉사시스템 유지관리\n참여 기간: 2025.04.28 - 2026.04.28\n분야: SW개발 > 응용SW개발',
            '의왕시 통합예약시스템 구축\n참여 기간: 2025.04.25 - 2026.04.28\n분야: SW개발 > 응용SW개발'
        ])
    ]
    for p in d['projects']:
        career.append((p['title'], ['기간: '+p['period'], '해당 능력: '+p['ability'], '상황: '+p['situation'], '행동: '+p['action'], '결과: '+p['result'], '도구: '+p['tools'], '근거: '+p['source']]))
    return {'resume.docx': make_docx('석근욱 이력서', resume), 'self-introduction.docx': make_docx('석근욱 자기소개서', introduction), 'career-description.docx': make_docx('석근욱 경력기술서', career)}


def page(data, stats, preview=False):
    a, d = data['approved-statements.json'], data['content-draft.json']
    esc = html.escape
    rendered_story = story(data, stats, preview)
    caps = a['capabilities'] or (d['capabilities'] if preview else [])
    note = '<div class="review-note">검토용 미리보기 · 새 본문과 능력 설명은 공개 승인 전입니다. 승인한 문장만 공개용 페이지에 반영됩니다.</div>' if preview and not a['story'] else ''
    paragraph_html = ''.join('<p>'+esc(p)+'</p>' for p in rendered_story) or '<p class="muted">자기소개 본문은 사용자 검토 후 공개됩니다.</p>'
    cards = ''.join(f'<article><span class="date">{esc(c["date"])} 기록</span><h3>{esc(c["ability"])}</h3><p>{esc(c["paragraph"])}</p><details><summary>기록 근거 보기</summary><blockquote>{esc(c["evidence"])}</blockquote><p class="source">출처: {esc(c["source"])}</p></details></article>' for c in caps)
    stat_cards = ''.join(f'<div class="stat"><strong>{stats[k]}<small>{unit}</small></strong><span>{label}</span></div>' for k, unit, label in [('record_days','일','기록한 날짜'),('open_count','건','아침 기록'),('close_count','건','마무리 기록'),('practiced','회','실천했다는 자기보고')])
    optional = ''.join(f'<span>{label}: '+ (f'{stats[k]["count"]}/{stats[k]["total"]} · '+esc(stats[k]['source']) if stats[k]['status']=='confirmed' else 'TODO: 실제 기록 확인 필요')+'</span>' for k,label in [('attendance','출석'),('assignments','제출')])
    documents = ''.join(f'<a class="document" href="documents/{name}" download><span>{label}</span><span>DOCX ↓</span></a>' for name,label in [('resume.docx','이력서'),('self-introduction.docx','자기소개서'),('career-description.docx','경력기술서')]) if preview or a['story'] else '<p>문서 공개는 자기소개 본문 검토 후 진행합니다.</p>'
    documents += '<a class="document" href="bra-submission.zip" download><span>문서와 자동 갱신 장치 전체</span><span>제출 ZIP ↓</span></a>'
    contact = esc(a['contact']['label']+': '+a['contact']['value']) if a['contact'] else 'TODO: 공개할 연락 수단 하나를 확인해 주세요.'
    timeline = ''.join(f'<div class="day {"miss" if not x["close"] else "failed" if "강점 행동: 못 했다" in x["close"] else "partial" if "강점 행동: 일부 실천했다" in x["close"] else "done"}" title="{esc(x["date"])} · {esc(next((s for s in (x["close"] or []) if s.startswith("강점 행동:")), "마무리 기록 없음"))}"><span>{x["date"][5:]}</span></div>' for x in sorted(data['ritual-history.json']['days'], key=lambda d:d['date']))
    return f'''<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="석근욱의 실제 경험과 리추얼 기록, 공개자료 연구를 정리한 자기소개"><meta name="robots" content="{'noindex,nofollow' if preview else 'index,follow'}"><title>석근욱 | 기록으로 전하는 나의 이야기</title><link rel="icon" href="favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="styles.css"></head>
<body><a class="skip" href="#main">본문으로 바로가기</a>{note}<header><a class="brand" href="#main">석근욱<span>PORTFOLIO</span></a><nav aria-label="주요 영역"><a href="#story">이야기</a><a href="#numbers">숫자</a><a href="#work">대표작</a><a href="#documents">이력서/문서</a></nav></header>
<main id="main"><section class="hero"><div><p class="eyebrow">배움과 행동을 돌아보는 기록</p><h1>석근욱</h1><p class="tagline">{esc(a['tagline'] or '한 줄 소개 승인 대기')}</p><p class="intro">말과 행동을 돌아본 경험부터<br>함께 문제를 풀고 기록을 이어가는 지금까지.</p><a class="button" href="#story">나의 이야기 읽기 <span aria-hidden="true">↗</span></a></div><aside class="hero-note"><span class="tiny">RECORDS, NOT RATINGS</span><p>잘되지 않은 날도<br>기록에 남겼습니다.</p><strong>{stats['record_days']}<small>일의 기록</small></strong><span class="source">{stats['period']}<br>제공된 리추얼 기록 기준</span></aside></section>
<section id="story" class="story section"><div class="section-label"><span>01 / STORY</span><h2>나의 이야기</h2><p>고난을 돌아보고<br>행동을 바꾸기까지</p></div><div class="prose">{paragraph_html}</div></section>
<section id="numbers" class="section numbers"><div class="section-label"><span>02 / RECORDS</span><h2>숫자로 보는 기록</h2><p>13주 과정 중 제공된 기록의 범위입니다.</p></div><div><div class="stats">{stat_cards}</div><p class="source">출처: ritual-history.json · {stats['period']} · 날짜별 open/close를 각 1건으로 계산</p><div class="days" aria-label="날짜별 마무리 기록">{timeline}</div><p class="legend">짙은 초록: 실천 · 연한 초록: 일부 실천 · 갈색: 못 했다 · 테두리: 마무리 미기록</p><p>마무리 {stats['close_count']}건 중 실천 {stats['practiced']}회, 일부 실천 {stats['partial']}회, 못 했다 {stats['not_practiced']}회입니다. 마무리 미기록은 실패로 계산하지 않습니다.</p><div class="recovery"><h3>잘되지 않은 날 이후에도</h3><p>{esc(stats['last_setback'] or '해당 없음')}의 미실천 기록 이후 마무리 기록은 {stats['after_setback_close']}개 날짜에 남아 있습니다. 수업 집중을 돌아본 기록이며 군 복무 경험의 회복률이나 객관적인 능력 점수가 아닙니다.</p></div><div class="optional">{optional}</div><details><summary>집계 기준과 전체 숫자</summary><p>각 숫자는 자기보고 기록의 수입니다. 출석·제출 전체 기간이나 13주 전체의 실천율을 뜻하지 않습니다. 키워드 횟수는 능력 점수로 사용하지 않습니다.</p><a href="metrics.json">집계 JSON 열기</a></details></div></section>
<section class="section capabilities"><div class="section-label"><span>03 / ACTIONS</span><h2>행동으로 보는<br>세 가지 능력</h2></div><div class="cap-grid">{cards or '<p>능력별 설명은 사용자 검토 후 공개됩니다.</p>'}</div></section>
<section id="work" class="section"><div class="section-label"><span>04 / SELECTED WORK</span><h2>대표작</h2><p>실제 결과물과<br>현재의 진행 상태</p></div><div class="works"><article class="featured"><span class="date">과제 10 · 작성 2026-09-11</span><h3>병사 휴대전화 사용 허용과<br>외부 소통 및 심리적 스트레스에 관한 공개자료 연구</h3><p>휴대전화 사용 허용이 외부 소통을 늘려 스트레스와 복무염증을 낮추는지 공개자료로 검토했습니다.</p><p>AI와 함께 정리한 원자료·표·한계를 확인하고 ‘현재 데이터만으로 판단하기 어려움’이라는 결론을 직접 선택했습니다. 6개 정책 지표의 두 시점 값과 차이를 다룹니다.</p><a class="text-link" href="paper.html">논문 공개용 사본 읽기 ↗</a><p class="source">원문 내용 유지 · 개인정보 규칙에 따라 연구자 이름을 익명화한 사본</p></article><article class="upcoming"><span class="date">과제 13 · 진행 예정 결과물</span><h3>과제 13 완료 후 추가 예정</h3><p>앱이 완성되면 실제 결과물과 수행 내용을 추가합니다. 완료일은 아직 확정되지 않았습니다.</p></article></div></section>
<section id="documents" class="section"><div class="section-label"><span>05 / DOCUMENTS</span><h2>이력서와 문서</h2></div><div>{documents}<p class="source">경력·학력·교육·자격과 연락처는 사용자 제공 정보를 기준으로 작성했습니다.</p></div></section>
<section class="section contact"><div class="section-label"><span>06 / CONTACT</span><h2>연락</h2></div><p>{contact}</p></section></main><footer>석근욱 <span>실제 경험과 기록을 바탕으로 작성했습니다.</span></footer></body></html>'''


def paper_html(text):
    lines, out, table = text.splitlines(), [], False
    for line in lines:
        if line.startswith('|'):
            if re.fullmatch(r'[|:\- ]+', line):
                continue
            if not table:
                out.append('<div class="table-scroll"><table>'); table = True
            out.append('<tr>' + ''.join('<td>'+html.escape(c.strip())+'</td>' for c in line.strip('|').split('|')) + '</tr>')
            continue
        if table:
            out.append('</table></div>'); table = False
        if line.startswith('#'):
            level = min(len(line) - len(line.lstrip('#')), 4)
            out.append(f'<h{level}>'+html.escape(line.lstrip('# '))+f'</h{level}>')
        elif line.strip() and line.strip() != '---':
            out.append('<p>'+html.escape(line)+'</p>')
    if table: out.append('</table></div>')
    return '<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>과제 10 논문 공개용 사본</title><link rel="stylesheet" href="styles.css"><body><main class="paper"><a href="index.html#work">← 자기소개로</a><p class="review-note">공개용 익명화 사본입니다. 원본의 연구자 실명은 가렸으며 연구 내용·수치는 유지했습니다. 재현 코드와 원자료는 원래 과제 10 패키지에 있습니다.</p>'+''.join(out)+'</main></body></html>'


def build(folder, destination, publish=False):
    data = load_inputs(folder)
    stats = metrics(data)
    a = data['approved-statements.json']
    if publish:
        ensure(a['story'] and a['tagline'] and len(a['capabilities']) == 3, '공개 중단: 본문·한 줄 소개·능력 설명의 사용자 승인 필요')
        ensure(not (destination/'site/review.html').exists(), '공개 출력에 검토 파일이 있습니다. 새 출력 폴더를 사용하세요')
    files = {'metrics.json': encoded(stats), 'candidates.json': encoded(candidates(data)),
             'story-draft.txt': ('\n\n'.join(story(data, stats, True))+'\n').encode('utf-8'),
             'site/index.html': page(data, stats).encode('utf-8'), 'site/metrics.json': encoded(stats)}
    if not publish:
        files['site/review.html'] = page(data, stats, True).encode('utf-8')
    for name in ('styles.css', 'favicon.svg'):
        files['site/'+name] = (BASE / 'templates' / name).read_bytes()
    files['site/paper.html'] = paper_html((folder/'paper-public.md').read_text(encoding='utf-8')).encode('utf-8')
    for name, content in build_docs(data, stats).items():
        files['documents/'+name] = content
        if a['story'] or not publish:
            files['site/documents/'+name] = content
    hashes = {k: hashlib.sha256(v).hexdigest() for k,v in sorted(files.items())}
    digest = hashlib.sha256(encoded(hashes)).hexdigest()
    files['manifest.json'] = encoded({'files': hashes, 'aggregate_sha256': digest})
    files['last-run.json'] = encoded({'status':'SUCCESS', 'publish_ready':bool(a['story'] and a['tagline'] and len(a['capabilities'])==3), 'input_sha256':{p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(folder.iterdir()) if p.is_file()}, 'aggregate_sha256':digest, 'output_file_count':len(files)+1, 'execution_time':'시간값을 출력에 넣지 않음 — 결정적 출력', 'story_characters_including_spaces':len('\n\n'.join(story(data, stats, True))), 'warnings': [x for x, condition in [('본문 승인 대기',not a['story']),('연락 수단 미확정',not a['contact']),('공개 URL 미확정',not a['public_url']),('출석 기록 미제공',stats['attendance']['status']=='unconfirmed'),('제출 현황 미제공',stats['assignments']['status']=='unconfirmed')] if condition]})
    # Build and validate everything in memory before touching existing output.
    destination = destination.resolve()
    ensure(destination != folder.resolve() and folder.resolve() not in destination.parents and destination not in folder.resolve().parents, '입력과 출력 경로는 서로 포함될 수 없습니다')
    destination.mkdir(parents=True, exist_ok=True)
    for name, content in files.items():
        path = destination / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as f:
            temp = Path(f.name); f.write(content)
        temp.replace(path)
    return digest


def main():
    parser = argparse.ArgumentParser(description='리추얼 재집계 및 승인 문장으로 사이트 재생성')
    parser.add_argument('--input', type=Path, default=BASE/'input')
    parser.add_argument('--output', type=Path, default=BASE/'output')
    parser.add_argument('--publish', action='store_true', help='사용자 승인이 모두 확인된 경우에만 공개용 생성')
    args = parser.parse_args()
    try:
        result = build(args.input.resolve(), args.output, args.publish)
    except (ValueError, OSError, ImportError, KeyError, TypeError) as exc:
        print('ERROR: '+str(exc), file=sys.stderr)
        return 1
    print('SUCCESS SHA-256 '+result)
    return 0


if __name__ == '__main__':
    sys.exit(main())
