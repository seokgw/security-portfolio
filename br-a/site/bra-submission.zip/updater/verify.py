"""Reproduce in a fresh folder and test meaningful failure boundaries."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

BASE = Path(__file__).resolve().parent
for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, 'reconfigure'):
        stream.reconfigure(encoding='utf-8')


def hashes(folder):
    return {p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(folder.rglob('*')) if p.is_file()}


def main():
    with tempfile.TemporaryDirectory(prefix='bra-reproduce-') as temp:
        root = Path(temp)
        for name in ('update.py','requirements.txt','README.md'):
            shutil.copy2(BASE/name, root/name)
        for name in ('input','templates'):
            shutil.copytree(BASE/name, root/name)
        def run(output, *args):
            return subprocess.run([sys.executable, '-X', 'utf8', 'update.py', '--output', output, *args], cwd=root, capture_output=True, text=True, encoding='utf-8')
        first, second = run('run1'), run('run2')
        if first.returncode or second.returncode:
            raise RuntimeError(first.stderr+second.stderr)
        before = hashes(root/'run1')
        matched = before == hashes(root/'run2')
        manifest = json.loads((root/'run1/manifest.json').read_text(encoding='utf-8'))
        path = root/'input/ritual-history.json'
        original = path.read_bytes()
        tests = {}
        path.write_text('{', encoding='utf-8')
        tests['invalid_json_preserves_output'] = run('run1').returncode != 0 and before == hashes(root/'run1')
        path.write_bytes(original)
        obj = json.loads(original)
        obj['days'][0].pop('open')
        path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
        tests['missing_field_preserves_output'] = run('run1').returncode != 0 and before == hashes(root/'run1')
        obj = json.loads(original)
        obj['days'].append(obj['days'][0])
        path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
        tests['duplicate_date_preserves_output'] = run('run1').returncode != 0 and before == hashes(root/'run1')
        path.write_bytes(original)
        approved_path = root/'input/approved-statements.json'
        approved_original = approved_path.read_bytes()
        approved = json.loads(approved_original)
        approved['story'] = None
        approved_path.write_text(json.dumps(approved,ensure_ascii=False),encoding='utf-8')
        tests['unapproved_publication_blocked'] = run('run1','--publish').returncode != 0 and before == hashes(root/'run1')
        approved_path.write_bytes(approved_original)
        draft_path = root/'input/content-draft.json'
        draft = json.loads(draft_path.read_text(encoding='utf-8'))
        draft['capabilities'][0]['evidence'] = '실제 기록에 존재하지 않는 검증용 문장'
        draft_path.write_text(json.dumps(draft,ensure_ascii=False),encoding='utf-8')
        tests['unsupported_evidence_blocked'] = run('run1').returncode != 0 and before == hashes(root/'run1')
        stats=json.loads((root/'run1/metrics.json').read_text(encoding='utf-8'))
        tests['status_counts_partition_close'] = stats['practiced']+stats['partial']+stats['not_practiced']+stats['unclassified_close']==stats['close_count']
        tests['absent_attendance_not_zero'] = stats['attendance']['status']=='confirmed' or stats['attendance']['total'] is None
        result = {'fresh_folder':'PASS','same_files':matched,'run1_sha256':manifest['aggregate_sha256'],'run2_sha256':json.loads((root/'run2/manifest.json').read_text(encoding='utf-8'))['aggregate_sha256'],'file_count':len(before),'all_files_sha256':before,'checks':tests,'result':'PASS' if matched and all(tests.values()) else 'FAIL','method':'새 임시 폴더에 README·실행 소스·입력·템플릿만 복사. 동일 Python 및 설치된 python-docx로 README 실행 명령 두 번 수행. 새 머신에서의 패키지 다운로드까지 테스트한 것은 아님.'}
        (BASE/'reproducibility.json').write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({k:v for k,v in result.items() if k!='all_files_sha256'},ensure_ascii=False))
        return 0 if result['result']=='PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
