@echo off
cd /d "%~dp0codex-daily"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\tools\start-standalone.ps1" -Port 5192
pause
